
package com.wr.controller;

import com.wr.bean.Employee1;
import com.wr.dao.EmpDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author MD WASIM REZA
 */
public class EmployeeController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        if (request.getParameter("insert") != null) {

            String name = request.getParameter("name");
            String desg = request.getParameter("desg");
            int sal = Integer.parseInt(request.getParameter("sal"));

            Employee1 emp = new Employee1();

            emp.setEname(name);
            emp.setDesg(desg);
            emp.setSalary(sal);

            boolean status = new EmpDao().save(emp);
            if (status) {
                request.getSession().setAttribute("sm" ,"Employee saved successfully");
            } 
            else {
                request.getSession().setAttribute("em", "Employee not saved!!");
            }
            request.getRequestDispatcher("/insert.jsp").forward(request, response);
        }
        
        else if (request.getParameter("update") != null) {
            int empid = Integer.parseInt(request.getParameter("empid"));
            String name = request.getParameter("name");
            String desg = request.getParameter("desg");
            int sal = Integer.parseInt(request.getParameter("sal"));

            Employee1 emp = new Employee1();
            emp.setEmpid(empid);
            emp.setEname(name);
            emp.setDesg(desg);
            emp.setSalary(sal);

            boolean status = new EmpDao().update(emp);
            if (status) {
                request.getSession().setAttribute("sm", "Employee updated successfully");
            } else {
                request.getSession().setAttribute("em", "Employee not updated!!");
            }
            request.getRequestDispatcher("/edit.jsp?empid=" + empid).forward(request, response);
        }
        
        else if (request.getParameter("for").equalsIgnoreCase("delete")) {

            int empid = Integer.parseInt(request.getParameter("empid"));
            Employee1 e = EmpDao.findEmp(empid);

            boolean status = new EmpDao().delete(e);
            if (status) {
                request.getSession().setAttribute("sm", "Employee deleted successfully");
            } else {
                request.getSession().setAttribute("em", "Employee not deleted!!");
            }
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }
        //view
         else if (request.getParameter("view")!=null) {
             ArrayList < Employee1 > emplist = EmpDao.getAllEmp();
        request.setAttribute("emplist", emplist);
        RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
        dispatcher.forward(request, response);

//            ArrayList<Employee1>  elist=new ArrayList();
//          
//          elist=EmpDao.getAllEmp();
//           request.getRequestDispatcher("/index.jsp").forward(request, response);
         }
        
    }

 @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       doPost(request, response);
    }
}


   
   
   
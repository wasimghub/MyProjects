/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wr.dao;

import com.wr.bean.Employee1;
import com.wr.util.HibernateUtil;
import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author MD WASIM REZA
 */
public class EmpDao {
  
    public boolean save(Employee1 emp){
        try{
        SessionFactory factory=HibernateUtil.getSessionFactory();
        Session session=factory.openSession();
        session.beginTransaction();
        session.save(emp);
        session.getTransaction().commit();
        session.close();
        return true;
        }
        catch(Exception e){
             return false;
        }
        
        }
    
    
     public boolean update(Employee1 emp){
        try{
        SessionFactory factory=HibernateUtil.getSessionFactory();
        Session session=factory.openSession();
        session.beginTransaction();
        session.update(emp);
        session.getTransaction().commit();
        session.close();
        return true;
        }
        catch(Exception e){
             return false;
        }
        
        }
      public boolean delete(Employee1 emp){
        try{
        SessionFactory factory=HibernateUtil.getSessionFactory();
        Session session=factory.openSession();
        session.beginTransaction();
        session.delete(emp);
        session.getTransaction().commit();
        session.close();
        return true;
        }
        catch(Exception e){
             return false;
        }
        
        }
    
    public static ArrayList getAllEmp(){
        SessionFactory factory=HibernateUtil.getSessionFactory();
        Session session=factory.openSession();
        //session.beginTransaction();
     ArrayList<Employee1>  elist= (ArrayList<Employee1>) session.createQuery("SELECT al FROM Employee1 al").list();
     elist.toString();
     session.close();
     return elist;
    }
    
    public static Employee1 findEmp(int empid){
         SessionFactory factory=HibernateUtil.getSessionFactory();
        Session session=factory.openSession();
      Employee1 e=  (Employee1)session.get(Employee1.class, empid);
    return e;
    }   
}
